package com.example.analysisimage.widget

import android.content.Context
import android.view.TextureView

class ScanImageView constructor(context: Context) :TextureView(context){
}