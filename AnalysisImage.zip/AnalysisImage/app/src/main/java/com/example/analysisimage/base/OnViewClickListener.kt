package com.example.analysisimage.base

import android.view.View

interface OnViewClickListener:View.OnClickListener {

    override fun onClick(v: View?){

    }

}