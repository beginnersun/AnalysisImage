package com.example.analysisimage.bean

data class PlantBean(var name:String?,var image:String?,var description:String?,var baike:String?)